#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <math.h>

// ---------- LCD ----------

LiquidCrystal_I2C lcd(0x27, 16, 2);

// ---------- Pins ----------

#define THERMISTOR_PIN A0
#define POT_PIN        A1
#define HEATER_PIN     9      // PWM pin
#define BUTTON_PIN     2

// ---------- Thermistor ----------

#define R_FIXED          100000.0
#define R_NOMINAL        100000.0
#define T_NOMINAL        25.0
#define BETA_COEFFICIENT 3950.0

// ---------- Control ----------

float currentTemp = 0;
int   setTemp = 0;
int   potTemp = 0;

bool lastButtonState = HIGH;

// ---------- Proportional Gain ----------

float Kp = 8.0;

byte degreeSymbol = 223;

void setup() {

  pinMode(HEATER_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  lcd.init();
  lcd.backlight();
  lcd.clear();

  lcd.setCursor(0,0); lcd.print("CT:");
  lcd.setCursor(6,0); lcd.print("ST:");
  lcd.setCursor(12,0); lcd.print("POT:");
}

void loop() {

  // ---------- POT ----------

  potTemp = map(analogRead(POT_PIN), 0, 1023, 0, 300);

  // ---------- BUTTON ----------

  bool buttonState = digitalRead(BUTTON_PIN);
  if (lastButtonState == HIGH && buttonState == LOW) {
    setTemp = potTemp;
    delay(300);
  }
  lastButtonState = buttonState;

  // ---------- THERMISTOR ----------

  int adc = analogRead(THERMISTOR_PIN);
  adc = constrain(adc, 1, 1022);

  float Rntc = R_FIXED * ((float)adc / (1023.0 - adc));

  currentTemp = log(Rntc / R_NOMINAL);
  currentTemp /= BETA_COEFFICIENT;
  currentTemp += 1.0 / (T_NOMINAL + 273.15);
  currentTemp = 1.0 / currentTemp;
  currentTemp -= 273.15;

  // ---------- HEATER CONTROL (P CONTROL) ----------

  float error = setTemp - currentTemp;
  int pwm = (int)(error * Kp);

  pwm = constrain(pwm, 0, 255);
  analogWrite(HEATER_PIN, pwm);

  // ---------- LCD ----------

  lcd.setCursor(0,1);
  lcd.print((int)currentTemp);
  lcd.write(degreeSymbol);
  lcd.print("C ");

  lcd.setCursor(6,1);
  lcd.print(setTemp);
  lcd.write(degreeSymbol);
  lcd.print("C ");

  lcd.setCursor(12,1);
  lcd.print(potTemp);
  lcd.write(degreeSymbol);
  lcd.print("C ");

  delay(500);
}
