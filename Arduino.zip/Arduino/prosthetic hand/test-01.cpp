/*
  ST3215 Servo — 180° to 0° sweep
  Board : ESP32 Servo Driver
  Port  : SVG (Serial on Serial1)

  ST3215 position range : 0 – 4095  (full 360°)
  180° = 2048   |   0° = 0
  Adjust SERIAL_RX / SERIAL_TX to your board's SVG pin numbers.
*/

#include <SCServo.h>       // Feetech SCServo library
void waitForStop();
SMS_STS servo;

// ── Pin config ──────────────────────────────────────────
#define SERIAL_RX   18     // Change to your board's RX pin
#define SERIAL_TX   19     // Change to your board's TX pin
#define SERVO_ID     3     // Default ID of ST3215

// ── Motion config ────────────────────────────────────────
#define POS_90     2550  // 180° in raw ticks (mid-point)
#define POS_0        20   // 0°  in raw ticks
#define SPEED        900   // 0–3400 (ticks/sec) — lower = slower
#define ACCEL         50   // 0–254 — acceleration profile
#define PAUSE_MS    1000   // Wait at each end (ms)

void setup() {
  Serial.begin(115200);
  Serial1.begin(1000000, SERIAL_8N1, SERIAL_RX, SERIAL_TX);
  servo.pSerial = &Serial1;
  delay(200);

  Serial.println("ST3215 sweep: 180° → 0°  starting...");


  // ── Move to 0° ───────────────────────────────────────
  Serial.println("Moving to 0°");
  servo.WritePosEx(SERVO_ID, POS_0, SPEED, ACCEL);
  waitForStop();
  delay(PAUSE_MS);


  // ── Move to 0° ───────────────────────────────────────
  Serial.println("Moving to 0°");
  servo.WritePosEx(SERVO_ID, POS_90, SPEED, ACCEL);
  waitForStop();
  delay(PAUSE_MS);
    Serial.println("Moving to 0°");
  servo.WritePosEx(SERVO_ID, POS_0, SPEED, ACCEL);
  waitForStop();
  delay(PAUSE_MS);


}

void loop() {

  // // ── Move to 180° ─────────────────────────────────────
  // Serial.println("Moving to 180°");
  // servo.WritePosEx(SERVO_ID, POS_180, SPEED, ACCEL);
  // waitForStop();
  // delay(PAUSE_MS);


}

// ── Block until servo stops moving ───────────────────────
void waitForStop() {
  delay(100);                          // Short settle before polling
  while (servo.ReadMove(SERVO_ID)) {   // 1 = still moving
    delay(20);
  }
}