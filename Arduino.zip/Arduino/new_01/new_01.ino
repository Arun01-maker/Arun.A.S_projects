#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <math.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

// -------- Pins --------
#define THERMISTOR_PIN A0
#define POT_PIN        A1
#define HEATER_PIN     9
#define BUTTON_PIN     2

// -------- Thermistor Parameters --------
#define SERIES_RESISTOR 10000
#define NOMINAL_RESISTANCE 100000
#define NOMINAL_TEMPERATURE 25
#define BETA_COEFFICIENT 3950

// -------- Control Parameters --------
float setTemperature = 0;
bool tempConfirmed = false;
bool heaterState = false;

const float hysteresis = 2.0;

bool lastButtonState = HIGH;

void setup() {
  pinMode(HEATER_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  digitalWrite(HEATER_PIN, LOW);

  lcd.init();
  lcd.backlight();
  lcd.clear();

  lcd.setCursor(0,0);
  lcd.print("Set Temp &");
  lcd.setCursor(0,1);
  lcd.print("Press Button");
}

void loop() {

  // -------- Read Button --------
  bool buttonState = digitalRead(BUTTON_PIN);

  if (lastButtonState == HIGH && buttonState == LOW) {
    tempConfirmed = true;
    delay(300);  // debounce
  }
  lastButtonState = buttonState;

  // -------- Read Potentiometer --------
  int potValue = analogRead(POT_PIN);
  float potTemp = map(potValue, 0, 1023, 30, 250);

  // -------- Read Thermistor --------
  int adcValue = analogRead(THERMISTOR_PIN);
  float resistance = SERIES_RESISTOR / ((1023.0 / adcValue) - 1.0);

  float temperature;
  temperature = resistance / NOMINAL_RESISTANCE;
  temperature = log(temperature);
  temperature /= BETA_COEFFICIENT;
  temperature += 1.0 / (NOMINAL_TEMPERATURE + 273.15);
  temperature = 1.0 / temperature;
  temperature -= 273.15;

  // -------- Save Set Temperature --------
  if (!tempConfirmed) {
    setTemperature = potTemp;
  }

  // -------- Heater Control --------
  if (tempConfirmed) {
    if (temperature <= (setTemperature - hysteresis)) {
      heaterState = true;
    }
    else if (temperature >= (setTemperature + hysteresis)) {
      heaterState = false;
    }
  } else {
    heaterState = false;
  }

  digitalWrite(HEATER_PIN, heaterState ? HIGH : LOW);

  // -------- LCD Display --------
  lcd.setCursor(0,0);
  lcd.print("Cur:");
  lcd.print(temperature,1);
  lcd.print("C    ");

  lcd.setCursor(0,1);
  lcd.print("Set:");
  lcd.print(setTemperature,0);
  lcd.print(" ");

  if (!tempConfirmed)
    lcd.print("WAIT");
  else if (heaterState)
    lcd.print("HEAT");
  else
    lcd.print("HOLD");

  delay(500);
}
