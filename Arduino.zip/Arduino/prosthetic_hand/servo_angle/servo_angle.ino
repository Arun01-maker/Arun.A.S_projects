/*
  ST3215 Servo — Serial Angle Control
  Board : ESP32 Servo Driver
*/

#include <SCServo.h>

void waitForStop();
SMS_STS servo;

// Pin configuration
#define SERIAL_RX   18
#define SERIAL_TX   19
#define SERVO_ID     5

// Motion configuration
#define SPEED        900
#define ACCEL         50

void setup() {
  Serial.begin(115200);
  Serial1.begin(1000000, SERIAL_8N1, SERIAL_RX, SERIAL_TX);

  servo.pSerial = &Serial1;
  delay(200);

  Serial.println("Enter angle (0–360):");
}

void loop() {

  if (Serial.available() > 0) {

    int angle = Serial.parseInt();

    // clear remaining serial buffer
    while (Serial.available()) {
      Serial.read();
    }

    if (angle >= 0 && angle <= 360) {

      int position = map(angle, 0, 360, 0, 4095);

      Serial.print("Moving to angle: ");
      Serial.print(angle);
      Serial.print(" | Position: ");
      Serial.println(position);

      servo.WritePosEx(SERVO_ID, position, SPEED, ACCEL);
      waitForStop();

      Serial.println("Position reached. Servo holding position.");
    }
    else {
      Serial.println("Invalid angle! Enter 0–360");
    }
  }
}

// Wait until motion stops
void waitForStop() {
  delay(100);
  while (servo.ReadMove(SERVO_ID)) {
    delay(20);
  }
}