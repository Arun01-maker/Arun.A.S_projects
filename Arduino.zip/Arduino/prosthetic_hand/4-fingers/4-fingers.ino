/*
  ST3215 Servo — Index, Middle, Ring/Little Finger Control
  Board : ESP32 Servo Driver
*/

#include <SCServo.h>

SMS_STS servo;
void waitForStop(int id);

// Pin configuration
#define SERIAL_RX   18
#define SERIAL_TX   19

// Servo IDs
#define INDEX_SERVO_ID   3
#define MIDDLE_SERVO_ID  4
#define RING_LITTLE_ID   2
#define THUMB_SERVO_ID   5
#define THUMB_ROTATION_ID  1

// Motion configuration
#define SPEED        900
#define ACCEL         50

void setup() {

  Serial.begin(115200);
  Serial1.begin(1000000, SERIAL_8N1, SERIAL_RX, SERIAL_TX);

  servo.pSerial = &Serial1;
  delay(200);

  Serial.println("Type 'index', 'middle', 'ring', 'little', 'thumb', or 'thumb_rot'");
}

void loop() {

  if (Serial.available()) {

    String command = Serial.readStringUntil('\n');
    command.trim();

    // -------- INDEX FINGER --------
    if (command == "index") {

      int pos20  = map(0, 0, 360, 0, 4095);
      int pos250 = map(150, 0, 360, 0, 4095);

      Serial.println("Index command received");

      servo.WritePosEx(INDEX_SERVO_ID, pos250, SPEED, ACCEL);
      waitForStop(INDEX_SERVO_ID);

      delay(1000);

      servo.WritePosEx(INDEX_SERVO_ID, pos20, SPEED, ACCEL);
      waitForStop(INDEX_SERVO_ID);

      Serial.println("Motion completed");
    }

    // -------- MIDDLE FINGER --------
    if (command == "middle") {

      int pos0   = map(0,   0, 360, 0, 4095);
      int pos180 = map(150, 0, 360, 0, 4095);

      Serial.println("Middle command received");

      servo.WritePosEx(MIDDLE_SERVO_ID, pos180, SPEED, ACCEL);
      waitForStop(MIDDLE_SERVO_ID);

      delay(1000);

      servo.WritePosEx(MIDDLE_SERVO_ID, pos0, SPEED, ACCEL);
      waitForStop(MIDDLE_SERVO_ID);

      Serial.println("Middle finger motion completed");
    }

    // -------- RING OR LITTLE FINGER --------
    if (command == "ring" || command == "little") {

      int pos100 = map(100, 0, 360, 0, 4095);
      int pos250 = map(250, 0, 360, 0, 4095);

      Serial.println("Ring/Little command received");

      servo.WritePosEx(RING_LITTLE_ID, pos250, SPEED, ACCEL);
      waitForStop(RING_LITTLE_ID);

      delay(1000);

      servo.WritePosEx(RING_LITTLE_ID, pos100, SPEED, ACCEL);
      waitForStop(RING_LITTLE_ID);

      Serial.println("Ring/Little finger motion completed");
    }// -------- THUMB FINGER --------
    if (command == "thumb") {

      int pos100 = map(100, 0, 360, 0, 4095);
      int pos200 = map(250, 0, 360, 0, 4095);

      Serial.println("Thumb command received");

      servo.WritePosEx(THUMB_SERVO_ID, pos200, SPEED, ACCEL);
      waitForStop(THUMB_SERVO_ID);

      delay(1000);

      servo.WritePosEx(THUMB_SERVO_ID, pos100, SPEED, ACCEL);
      waitForStop(THUMB_SERVO_ID);

      Serial.println("Thumb motion completed");
    }// -------- THUMB ROTATION --------
    if (command == "thumb_rot") {

      int pos40  = map(40, 0, 360, 0, 4095);
      int pos120 = map(120, 0, 360, 0, 4095);

      Serial.println("Thumb rotation command received");

      servo.WritePosEx(THUMB_ROTATION_ID, pos120, SPEED, ACCEL);
      waitForStop(THUMB_ROTATION_ID);

      delay(1000);

      servo.WritePosEx(THUMB_ROTATION_ID, pos40, SPEED, ACCEL);
      waitForStop(THUMB_ROTATION_ID);

      Serial.println("Thumb rotation completed");
    }
  
  }
}


// Wait until motion stops
void waitForStop(int id) {
  delay(100);
  while (servo.ReadMove(id)) {
    delay(20);
  }
}