#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <math.h>

#define THERMISTOR_PIN A0
#define SERIES_RESISTOR 100000
#define NOMINAL_RESISTANCE 100000
#define NOMINAL_TEMPERATURE 25
#define BETA_COEFFICIENT 3950

LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  Serial.begin(9600);

  lcd.init();
  lcd.backlight();
  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print("Thermistor OK");
  delay(1500);
  lcd.clear();

  Serial.println("Thermistor test started");
}

void loop() {
  int adcValue = analogRead(THERMISTOR_PIN);

  // ADC to resistance
  float resistance = SERIES_RESISTOR * (1023.0 / adcValue - 1.0);

  // Resistance to temperature (Celsius)
  float temperature;
  temperature = resistance / NOMINAL_RESISTANCE;
  temperature = log(temperature);
  temperature /= BETA_COEFFICIENT;
  temperature += 1.0 / (NOMINAL_TEMPERATURE + 273.15);
  temperature = 1.0 / temperature;
  temperature -= 273.15;

  // -------- LCD OUTPUT --------
  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(temperature, 1);
  lcd.print(" C   ");   // clear extra chars

  lcd.setCursor(0, 1);
  lcd.print("ADC: ");
  lcd.print(adcValue);
  lcd.print("     ");

  // -------- SERIAL OUTPUT --------
  Serial.print("ADC: ");
  Serial.print(adcValue);
  Serial.print(" | Temp: ");
  Serial.print(temperature, 1);
  Serial.println(" C");

  delay(1000);
}
