#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <math.h>

// ---------- LCD ----------
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ---------- Pins ----------
#define THERMISTOR_PIN A0
#define POT_PIN        A1
#define HEATER_PIN     9
#define BUTTON_PIN     2

// ---------- Thermistor (NTC 100K 3950) ----------
#define SERIES_RESISTOR      10000
#define NOMINAL_RESISTANCE  100000
#define NOMINAL_TEMPERATURE 25
#define BETA_COEFFICIENT    3950

// ---------- Control ----------
float currentTemp = 0.0;
float setTemp     = 50.0;
int   potTemp     = 50;

bool heaterState = false;
const float hysteresis = 2.0;

bool lastButtonState = HIGH;

// Degree symbol for LCD
byte degreeSymbol = 223;

void setup() {
  pinMode(HEATER_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  digitalWrite(HEATER_PIN, LOW);

  lcd.init();
  lcd.backlight();
  lcd.clear();

  // ----- Header (printed once) -----
  lcd.setCursor(0,0);   lcd.print("CT:");
  lcd.setCursor(6,0);   lcd.print("ST:");
  lcd.setCursor(12,0);  lcd.print("POT:");
}

void loop() {

  // ---------- Potentiometer (Live preview) ----------
  int potValue = analogRead(POT_PIN);
  potTemp = map(potValue, 0, 1023, 30, 250);

  // ---------- Button (Confirm Set Temperature) ----------
  bool buttonState = digitalRead(BUTTON_PIN);
  if (lastButtonState == HIGH && buttonState == LOW) {
    setTemp = potTemp;
    delay(250);   // debounce
  }
  lastButtonState = buttonState;

  // ---------- Thermistor Reading ----------
  int adc = analogRead(THERMISTOR_PIN);
  float resistance = SERIES_RESISTOR / ((1023.0 / adc) - 1.0);

  currentTemp = resistance / NOMINAL_RESISTANCE;
  currentTemp = log(currentTemp);
  currentTemp /= BETA_COEFFICIENT;
  currentTemp += 1.0 / (NOMINAL_TEMPERATURE + 273.15);
  currentTemp = 1.0 / currentTemp;
  currentTemp -= 273.15;

  // ---------- Heater Control ----------
  if (currentTemp <= (setTemp - hysteresis))
    heaterState = true;
  else if (currentTemp >= (setTemp + hysteresis))
    heaterState = false;

  digitalWrite(HEATER_PIN, heaterState ? HIGH : LOW);

  // ---------- LCD VALUES (with °C) ----------

  // Current Temperature
  lcd.setCursor(0,1);
  if (currentTemp < 100) lcd.print("0");
  lcd.print(currentTemp,1);
  lcd.write(degreeSymbol);
  lcd.print("C");

  // Set Temperature
  lcd.setCursor(6,1);
  if (setTemp < 100) lcd.print(" ");
  lcd.print((int)setTemp);
  lcd.write(degreeSymbol);
  lcd.print("C");

  // Potentiometer Temperature
  lcd.setCursor(12,1);
  if (potTemp < 100) lcd.print(" ");
  lcd.print(potTemp);
  lcd.write(degreeSymbol);
  lcd.print("C");

  delay(400);
}
