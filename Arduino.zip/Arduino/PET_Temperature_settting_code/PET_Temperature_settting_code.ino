#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

// Pin definitions
#define POT_PIN A1          // 🔄 Changed from A0 to A1
#define BUTTON_PIN 2

int setTemp = 0;
int savedTemp = 0;
bool lastButtonState = HIGH;

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  lcd.init();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("Temp Controller");
  delay(2000);
  lcd.clear();
}

void loop() {
  // Read potentiometer
  int potValue = analogRead(POT_PIN);

  // Map to temperature (0–300°C)
  setTemp = map(potValue, 0, 1023, 0, 300);

  // Read button
  bool buttonState = digitalRead(BUTTON_PIN);

  // Detect button press
  if (lastButtonState == HIGH && buttonState == LOW) {
    savedTemp = setTemp;   // Save temperature
    lcd.clear();
  }

  lastButtonState = buttonState;

  // Display
  lcd.setCursor(0, 0);
  lcd.print("Set Temp: ");
  lcd.print(setTemp);
  lcd.print((char)223); // Degree symbol
  lcd.print("C  ");

  lcd.setCursor(0, 1);
  lcd.print("Saved: ");
  lcd.print(savedTemp);
  lcd.print((char)223);
  lcd.print("C   ");

  delay(200);
}
